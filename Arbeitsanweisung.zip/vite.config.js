import { defineConfig } from 'vite';

export default defineConfig({
  // Keine spezielle Konfiguration nötig für den Start
  // Der Alias für 'three' ist oft nicht mehr nötig bei neueren Vite/Three Versionen
});